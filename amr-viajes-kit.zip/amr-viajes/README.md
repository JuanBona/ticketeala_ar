# AMR Viajes

Sistema de gestión de viajes corporativos con verificación de comprobantes para la Mutual AMR.
Proyecto Final ISI · UTN FRRo · 2026.

## Contenido

| Ruta | Qué es |
|---|---|
| `CLAUDE.md` | Contexto del proyecto para Claude Code (se carga solo al abrirlo en esta carpeta) |
| `docs/fuente/etapa3.pdf` | Documento de Etapa 3: la especificación |
| `docs/decisiones.md` | Correcciones al modelo que hay que acordar antes de programar |
| `docs/plan-trabajo.md` | Roles, iteraciones hasta el 18/12 y forma de trabajo |
| `docs/casos-de-uso.md` | Alcance del prototipo por caso de uso |
| `docs/modelo-datos.sql` | Esquema PostgreSQL de referencia (probado) |
| `docs/motor-verificacion.md` | Señales, puntaje, decisión y métricas del motor |
| `docs/pantallas.md` | Pantallas, rutas y las que faltan diseñar |
| `design/` | Capturas, HTML de referencia y fuentes de las dos propuestas visuales |
| `data/eval/` | Set de evaluación del motor |
| `PROMPTS.md` | Prompts en orden, por rol |
| `apps/*/CLAUDE.md`, `services/verifier/CLAUDE.md` | Reglas de cada parte |

## Primeros pasos

1. Completar en `CLAUDE.md` el estilo visual elegido.
2. `git init`, primer commit y subir a un repo privado de GitHub con los tres como colaboradores.
3. Cada uno: instalar Claude Code, clonar, abrir una terminal en la carpeta y ejecutar `claude`.
4. Seguir `PROMPTS.md` según el rol.
