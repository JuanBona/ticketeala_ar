# Cambios para CLAUDE.md

## 1. Reemplazar la línea de "Fechas" (sección "Alcance de este repositorio") por:

Fechas: 26/10 tercera entrega del documento (hecha) · 23/11 circuito punta a punta funcionando ·
13/12 código congelado · 18/12 entrega del prototipo. Plan completo en `docs/plan-trabajo.md`.

## 2. Reemplazar toda la sección "## Forma de trabajo" por:

## Forma de trabajo

- El equipo programa poco: explicá en lenguaje simple, definí los términos técnicos y no des nada
  por sabido. Si un plan tiene más de 5 pasos, partilo en tareas más chicas.
- Dueños: Juan Cruz (`apps/api`, `infra`, `docs/`), Manu (`services/verifier`, `data/eval`),
  Felipe (`apps/web`, `apps/mobile`, `design/`). Si la tarea requiere tocar carpetas de otro,
  frená y avisá antes de cambiarlas.
- Una sesión = una tarea = una rama = un PR. Ramas `feat/uc02-s08-dhash`, `fix/...`.
- Plan primero: no edites archivos hasta que el plan esté aprobado.
- Código, nombres y commits en inglés; textos de interfaz en español rioplatense.
- Cada regla de negocio y cada señal del motor tiene tests. No hay PR sin tests en verde.
- Si fallás dos veces en lo mismo, frená y explicá qué pasa en vez de seguir probando.
- Al terminar, el usuario va a pedir `/explicar`; la explicación va en la descripción del PR.
